/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lesson9;

public class SVPoly {

	private String hoTen;

	private Integer diemTB;

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public Integer getDiemTB() {
		return diemTB;
	}

	public void setDiemTB(Integer diemTB) {
		this.diemTB = diemTB;
	}

	@Override
	public String toString() {
		return "hoTen = '" + hoTen + '\'' + ", diemTB = " + diemTB;
	}

}
